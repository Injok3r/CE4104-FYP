
from pathlib import Path
from ultralytics import YOLO

DEFAULT_MODEL_PATH = r"C:\Users\xilin\Desktop\FYP\Results\train\v1\weights\best.pt"
DEFAULT_SOURCE_PATH = r"C:\Users\xilin\Desktop\FYP\CONCORNET2023-main\Images\Final Trial"

DEFAULT_PROJECT = r"C:\Users\xilin\Desktop\FYP\Results\visualization"
DEFAULT_RUN_NAME = "final_v1" 
DEFAULT_CONF = 0.524  


def main():
    model_path = Path(DEFAULT_MODEL_PATH)
    source_path = Path(DEFAULT_SOURCE_PATH)

    if not model_path.is_file():
        raise FileNotFoundError(f"Model file not found:\n  {model_path}")

    if not source_path.exists():
        raise FileNotFoundError(f"Source path not found:\n  {source_path}")

    print("==============================================")
    print(" YOLOv8 PREDICTION SCRIPT")
    print("==============================================")
    print(f"[INFO] Model : {model_path}")
    print(f"[INFO] Source: {source_path}")
    print(f"[INFO] Output: {DEFAULT_PROJECT}\\{DEFAULT_RUN_NAME}")
    print(f"[INFO] Conf  : {DEFAULT_CONF}")
    print("==============================================\n")

    model = YOLO(str(model_path))

    results = model.predict(
        source=str(source_path),    
        conf=DEFAULT_CONF,
        save=True,                 
        project=DEFAULT_PROJECT,   
        name=DEFAULT_RUN_NAME,     
        exist_ok=True,)
    
    print("\n[INFO] Prediction complete")
    print(f"[INFO] Number of result items: {len(results)}")
    print(f"[INFO] Results saved in:\n  {Path(DEFAULT_PROJECT) / DEFAULT_RUN_NAME}")


if __name__ == "__main__":
    main()
