from ultralytics import YOLO
import torch
from pathlib import Path

# Path to your dataset definition YAML (train/val/test)
DATA_YAML = r"c:\Users\xilin\Desktop\FYP\CONCORNET2023-main\concrete.yaml"


def evaluate_on_test_set(model):

    print("\n[INFO] Running evaluation on TEST SET...\n")

    metrics = model.val(
        data=DATA_YAML,
        split="test",
        imgsz=832
    )

    rd = metrics.results_dict

    precision = rd.get("metrics/precision(B)")
    recall = rd.get("metrics/recall(B)")
    map50 = rd.get("metrics/mAP50(B)")
    map5095 = rd.get("metrics/mAP50-95(B)")

    # Compute F1 score
    if precision is not None and recall is not None and (precision + recall) > 0:
        f1 = 2 * precision * recall / (precision + recall)
    else:
        f1 = None

    print("========== FINAL TEST METRICS ==========")
    print(f"Precision      : {precision:.4f}" if precision is not None else "Precision      : N/A")
    print(f"Recall         : {recall:.4f}"     if recall is not None else "Recall         : N/A")
    print(f"F1 Score       : {f1:.4f}"         if f1 is not None else "F1 Score       : N/A")
    print(f"mAP@0.50       : {map50:.4f}"      if map50 is not None else "mAP@0.50       : N/A")
    print(f"mAP@0.50:0.95  : {map5095:.4f}"    if map5095 is not None else "mAP@0.50:0.95  : N/A")
    print("========================================\n")


if __name__ == "__main__":

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}\n")

    print("==============================================")
    print(" YOLOv8 TRAIN / EVALUATE SCRIPT")
    print("==============================================")
    print("Options:")
    print("  Y = Train a new model")
    print("  N = Use an existing best.pt")
    print("==============================================\n")

    choice = input("Train new model? (y/n): ").strip().lower()

    if choice == "y":
        print("\n[INFO] Training new YOLOv8n model...\n")

        model = YOLO("yolov8n.pt")

        model.train(
            data=DATA_YAML,
            epochs=100,
            imgsz=832,
            device=device
        )

        print("\n[INFO] Training complete.")
        print("[INFO] Loading best.pt from training run...\n")

        trained_weight_path = model.ckpt_path 
        model = YOLO(trained_weight_path)

        evaluate_on_test_set(model)

    else:
        print("\n[INFO] Running evaluation on an existing trained model.")
        weight_path = input("Enter path to best.pt: ").strip()

        weight_path = Path(weight_path)

        if not weight_path.is_file():
            raise FileNotFoundError(f"\n❌ ERROR: best.pt NOT FOUND at:\n{weight_path}")

        print(f"\n[INFO] Loading model from:\n{weight_path}\n")
        model = YOLO(str(weight_path))

        evaluate_on_test_set(model)
