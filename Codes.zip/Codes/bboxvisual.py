import cv2
from pathlib import Path
from typing import List, Tuple

IMAGES_DIR = Path(r"C:\Users\xilin\OneDrive\Desktop\FYP\CONCORNET2023-main\Images\test\images")
LABELS_DIR = Path(r"C:\Users\xilin\OneDrive\Desktop\FYP\CONCORNET2023-main\Images\test\labels")
OUT_DIR    = Path(r"C:\Users\xilin\OneDrive\Desktop\FYP\CONCORNET2023-main\Images\test\boxed")

COPY_WHEN_MISSING = False
# 

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def yolo_to_xyxy(xc: float, yc: float, w: float, h: float, W: int, H: int) -> Tuple[int, int, int, int]:
    x1 = int((xc - w / 2) * W)
    y1 = int((yc - h / 2) * H)
    x2 = int((xc + w / 2) * W)
    y2 = int((yc + h / 2) * H)
    return max(0, x1), max(0, y1), min(W - 1, x2), min(H - 1, y2)


def read_yolo_labels(label_path: Path) -> List[Tuple[int, float, float, float, float]]:
    boxes = []
    with label_path.open("r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) == 5:
                try:
                    cls = int(parts[0])
                    xc, yc, w, h = map(float, parts[1:])
                    boxes.append((cls, xc, yc, w, h))
                except ValueError:
                    pass
    return boxes


def color_for_class(cls_id: int):
    return ((37 * (cls_id + 1)) % 255, (17 * (cls_id + 1)) % 255, (233 * (cls_id + 1)) % 255)


def draw_boxes_on_image(img, boxes: List[Tuple[int, float, float, float, float]]):
    H, W = img.shape[:2]
    thickness = max(2, round(0.002 * (H + W)))
    font_scale = max(0.5, 0.0008 * (H + W))
    font = cv2.FONT_HERSHEY_SIMPLEX

    for cls, xc, yc, w, h in boxes:
        x1, y1, x2, y2 = yolo_to_xyxy(xc, yc, w, h, W, H)
        color = color_for_class(cls)
        cv2.rectangle(img, (x1, y1), (x2, y2), color, thickness)
        label = str(cls)
        (tw, th), baseline = cv2.getTextSize(label, font, font_scale, thickness)
        tx1, ty1 = x1, max(0, y1 - th - baseline - 3)
        tx2, ty2 = x1 + tw + 6, y1
        cv2.rectangle(img, (tx1, ty1), (tx2, ty2), color, -1)
        cv2.putText(img, label, (x1 + 3, y1 - 3), font, font_scale, (255, 255, 255), thickness, cv2.LINE_AA)


def process_all():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    images = sorted([p for p in IMAGES_DIR.iterdir() if p.suffix.lower() in IMG_EXTS])

    n_total = len(images)
    n_drawn = 0
    n_missing = 0

    for img_path in images:
        stem = img_path.stem
        label_path = LABELS_DIR / f"{stem}.txt"
        out_path = OUT_DIR / img_path.name

        img = cv2.imread(str(img_path))
        if img is None:
            print(f"Cannot read image: {img_path}")
            continue

        if label_path.exists():
            boxes = read_yolo_labels(label_path)
            if boxes:
                draw_boxes_on_image(img, boxes)
                cv2.imwrite(str(out_path), img)
                n_drawn += 1
            else:
                if COPY_WHEN_MISSING:
                    cv2.imwrite(str(out_path), img)
                n_missing += 1
        else:
            if COPY_WHEN_MISSING:
                cv2.imwrite(str(out_path), img)
            n_missing += 1

    print(f"[DONE] Total: {n_total} | With boxes: {n_drawn} | Without labels: {n_missing}")
    print(f"[OUT] Saved results to: {OUT_DIR}")


if __name__ == "__main__":
    process_all()
