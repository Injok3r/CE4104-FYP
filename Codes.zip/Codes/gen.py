from openai import OpenAI
from PIL import Image
import base64, io, os, requests
from pathlib import Path
import time

INPUT_DIR  = r"C:\Users\xilin\OneDrive\Desktop\FYP\CONCORNET2023-main\Images\testing for training\4chatimg"
OUTPUT_DIR = r"C:\Users\xilin\OneDrive\Desktop\FYP\CONCORNET2023-main\Images\testing for training\Synth"
API_KEY    = ""your_openai_api_key_here" 

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}

SLEEP_BETWEEN_CALLS = 0.3

PROMPT = (
    "Task: For each uploaded image, generate 1 photorealistic image that preserves the same scene, geometry, lighting, "
    "and background context while adding only small natural variation. Do NOT crop, zoom in, or change the framing. "
    "The same field of view and perspective must be kept. The ROI bounding boxes given in each .txt file indicate the "
    "regions of interest — e.g. corrosion damage, exposed rebar, or spalling. ROI rules: – Keep the target region fully "
    "inside the same position and size as marked in the ROI. – Preserve the original color and lighting of the ROI (no recoloring). "
    "– Do not draw or show the bounding box itself in the final image. – Maintain the same apparent size, texture, and material. "
    "Scene & geometry constraints: – Keep all visible structure: beam edges, column faces, soffits, slabs, joints, and pipes. "
    "– Preserve perspective lines, vanishing points, and shadows. – Maintain the same scale (±5%), lighting direction (±0.3 EV), "
    "and white balance (±300 K). – If the output must be 1024×1024, pad/letterbox rather than cropping. Appearance constraints: "
    "– Retain concrete micro-texture, cracks, stains, and paint flakes. – Do not smooth, denoise, or beautify. – Keep photographic "
    "realism with slight sensor noise and lighting imperfections. Micro variation: – Apply at most one of: rotation (±3°), tiny zoom "
    "(0.98–1.02), or shift ≤2% (no flip). Negative constraints: – No bounding boxes, outlines, labels, borders, text, logos, or new "
    "objects. – No added or removed rebars or structural elements. – No synthetic look or HDR enhancement. Output: – 1 image per "
    "reference (1:1). – Size: 1024×1024. – Style: documentary realism (true-to-life concrete corrosion photo)."
)

client = OpenAI(api_key=API_KEY)

def ensure_dir(p: str | Path) -> Path:
    p = Path(p)
    p.mkdir(parents=True, exist_ok=True)
    return p

def is_image(path: Path) -> bool:
    return path.suffix.lower() in IMAGE_EXTS

def pil_to_png_bytes(im: Image.Image) -> io.BytesIO:
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    buf.seek(0)
    buf.name = "input_image.png"  
    return buf

def main():
    in_dir = Path(INPUT_DIR)
    out_dir = ensure_dir(OUTPUT_DIR)

    if not in_dir.exists():
        raise FileNotFoundError(f"Input directory not found: {in_dir}")

    files = sorted([p for p in in_dir.iterdir() if p.is_file() and is_image(p)])
    if not files:
        print(f"No images found in: {in_dir}")
        return

    print(f"Found {len(files)} image(s) in {in_dir}")
    successes, failures = 0, 0

    for idx, img_path in enumerate(files, start=1):
        try:
            img = Image.open(img_path).convert("RGBA")
            buffer = pil_to_png_bytes(img)

            print(f"[{idx}/{len(files)}] Processing: {img_path.name}")

            response = client.images.edit(
                model="gpt-image-1-mini",
                prompt=PROMPT,
                image=buffer,
                size="1024x1024",
            )

            data = response.data[0]

            out_name = f"{img_path.stem}_synth.png"
            out_path = out_dir / out_name

            if getattr(data, "b64_json", None):
                image_bytes = base64.b64decode(data.b64_json)
                with open(out_path, "wb") as f:
                    f.write(image_bytes)
                print(f"Saved: {out_path}")
                successes += 1

            elif getattr(data, "url", None):
                image_url = data.url
                image_bytes = requests.get(image_url, timeout=60).content
                with open(out_path, "wb") as f:
                    f.write(image_bytes)
                print(f"Saved (from URL): {out_path}")
                successes += 1

            else:
                print(" No image data in response.")
                failures += 1

            if SLEEP_BETWEEN_CALLS > 0:
                time.sleep(SLEEP_BETWEEN_CALLS)

        except Exception as e:
            print(f"Error on {img_path.name}: {e}")
            failures += 1

    print(f"\nDone. Success: {successes}, Failed: {failures}, Output folder: {out_dir}")

if __name__ == "__main__":
    main()
